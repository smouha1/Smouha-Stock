plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.smouha.stock"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.smouha.stock"
        minSdk = 21
        targetSdk = 34
        versionCode = 100
        versionName = "1.0.0"
    }

    signingConfigs {
        create("release") {
            val storePath = System.getenv("SMOUHA_KEYSTORE_FILE")
                ?: "/tmp/smouha-keys/smouha-release.jks"
            storeFile = file(storePath)
            storePassword = System.getenv("SMOUHA_KEYSTORE_PASS") ?: "SmouhaOps2026#Key"
            keyAlias = System.getenv("SMOUHA_KEY_ALIAS") ?: "smouha_release_key"
            keyPassword = System.getenv("SMOUHA_KEY_PASS") ?: "SmouhaOps2026#Key"
            enableV1Signing = true
            enableV2Signing = true
            enableV3Signing = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            signingConfig = signingConfigs.getByName("release")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("androidx.webkit:webkit:1.10.0")
}
